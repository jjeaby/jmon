# jmon is Machine's Cpu, Memory, Cuda Information Monitoring and Save with InfluxDB 


